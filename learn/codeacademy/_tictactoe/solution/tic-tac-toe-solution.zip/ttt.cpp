#include <iostream>
#include "play.hpp"

int main() {

  introduction();
  
  take_turn();

  end_game();
    
}